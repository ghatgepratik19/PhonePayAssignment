import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Iterator;
import java.io.IOException;
import java.util.LinkedList;
public class App {
    public static void main(String[] args) throws Exception {
        JSONParser parser = new JSONParser();
        LinkedList<String> team1Players=new LinkedList<>();
        LinkedList<String> team2Players=new LinkedList<>();
        int noOfOvers=0;
        int noOfPlayers=0;
        try {     
            String root = System.getProperty("user.dir");
            Object obj = parser.parse(new FileReader(root+"/resources/data.json"));
            JSONObject jsonObject =  (JSONObject) obj;
            noOfOvers = Integer.parseInt((String) jsonObject.get("noOfOvers"));
            noOfPlayers = Integer.parseInt((String) jsonObject.get("noOfPlayers"));
            JSONArray team1Player = (JSONArray) jsonObject.get("team1Players");
            Iterator<String> iterator = team1Player.iterator();
            while (iterator.hasNext()) {
             team1Players.add(iterator.next());
            }
            JSONArray team2Player = (JSONArray) jsonObject.get("team2Players");
            iterator = team2Player.iterator();
            while (iterator.hasNext()) {
             team2Players.add(iterator.next());
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        if(noOfPlayers!=team1Players.size() || noOfPlayers!=team2Players.size()){
            System.out.println("Incorrect Data");
            return;
        }
       Match m= new Match(noOfPlayers, noOfOvers,team1Players, team2Players);
        m.SetBattingOrderOfTeams();
        String result = m.StartMatch();
        System.out.println(result);
    }
}
