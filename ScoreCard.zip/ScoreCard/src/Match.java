import java.util.LinkedList;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
public class Match {
    Team team1;
    Team team2;
    int noOfOvers;
    public Match(int noOfPlayers,int noOfOvers,LinkedList<String> team1PlayerNames,LinkedList<String> team2PlayerNames) {
        team1= new Team(noOfPlayers, team1PlayerNames);
        team2= new Team(noOfPlayers, team2PlayerNames);
        this.noOfOvers = noOfOvers;
    }

    public void SetBattingOrderOfTeams(){
        LinkedList<Player> team1PlayersOrder = team1.players;
        //logic for updating player order
        team1.setPlayerOrder(team1PlayersOrder);
        LinkedList<Player> team2PlayersOrder = team2.players;
        team2.setPlayerOrder(team2PlayersOrder);
    }

    public String StartMatch(){
        System.out.println("No. of players for each team: "+team1.players.size());
        System.out.println("No. of overs: "+noOfOvers);
        StartFirstTeamBatting("Team 1",team1);
        StartSecondTeamBatting("Team 2",team2,team1.score.totalScore);
        String result="";
        if(team1.score.totalScore>team2.score.totalScore){
            result= "Result: Team 1 won the match by"+(team1.score.totalScore-team2.score.totalScore)+" runs";
        }else if(team1.score.totalScore<team2.score.totalScore){
             result = "Result: Team 2 won the match by"+(team2.playerOrder.size()+2)+" wickets";
        }else{
            result ="No result";
        }
        return result;
    }

    public void StartFirstTeamBatting(String teamName,Team team){
        BufferedReader inp = new BufferedReader (new InputStreamReader(System.in));
        System.out.println("Batting Order for "+teamName+":");
        team.playerOrder.forEach(s -> System.out.println(s.playerName));
        team.score.over=0;
        team.score.balls=0;
        LiveScore.batsman1 = team.playerOrder.poll();
        LiveScore.batsman2 = team.playerOrder.poll();
        while(team.score.over<noOfOvers){
            team.score.over +=1;
            team.score.balls=0;
            System.out.println("Over "+team.score.over+":");
            while(team.score.balls<6){
                try{
                    String str = inp.readLine();
                    parseInputdata(team,str);
                    if(LiveScore.batsman1==null || LiveScore.batsman2==null){
                        return;
                    }
                }catch(IOException ex){
                    System.out.println("Exception in input data reading:"+ex.getMessage());
                }
                
            }
            LiveScore.switchBatsman();
            System.out.println("Scorecard for "+teamName+":");
            LiveScore.PrintScorecard(team);
        }

    }
    public void StartSecondTeamBatting(String teamName,Team team,int targetScore){
        BufferedReader inp = new BufferedReader (new InputStreamReader(System.in));
        System.out.println("Batting Order for "+teamName+":");
        team.playerOrder.forEach(s -> System.out.println(s.playerName));
        team.score.over=0;
        team.score.balls=0;
        LiveScore.batsman1 = team.playerOrder.poll();
        LiveScore.batsman2 = team.playerOrder.poll();
        while(team.score.over<noOfOvers){
            team.score.over +=1;
            team.score.balls=0;
            System.out.println("Over "+team.score.over+":");
            while(team.score.balls<6){
                try{
                    String str = inp.readLine();
                    parseInputdata(team,str);
                    if(team.score.totalScore>targetScore){
                        return;
                    }
                    if(LiveScore.batsman1==null || LiveScore.batsman2==null){
                        return;
                    }
                }catch(IOException ex){
                    System.out.println("Exception in input data reading:"+ex.getMessage());
                }
            }
            LiveScore.switchBatsman();
            System.out.println("Scorecard for "+teamName+":");
            LiveScore.PrintScorecard(team);
        }
    }

    public void parseInputdata(Team team,String str){
        if(str.equals("")){
            System.out.println("Input should not be Blank. Press Cntl+C to stop");
            return;
        }
        str = str.toLowerCase();
        switch(str){
            case "w":
            LiveScore.batsman1.balls +=1;
            LiveScore.batsman1=team.playerOrder.poll();
            team.score.balls +=1;
            break;
            case "wd":
            LiveScore.addRuns(team, 1, true);
            break;
            case "nb":
            LiveScore.addRuns(team, 1, true);
            break;
            default:
            try{
            int runs = Integer.parseInt(str);
            team.score.balls +=1;
            LiveScore.addRuns(team, runs, false);
            }catch(NumberFormatException ex){
                System.out.println("Please insert correct input. W-wicket, Wd-Wide,Nb-no ball, 1to6 number for runs.");
            }
            
        }
    }

}
