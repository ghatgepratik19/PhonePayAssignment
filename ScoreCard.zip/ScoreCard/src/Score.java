public class Score {
    int totalScore;
    int over;
    int balls;
    
    public int getTotalScore() {
        return totalScore;
    }
    public void setTotalScore(int totalScore) {
        this.totalScore = totalScore;
    }
    public int getOver() {
        return over;
    }
    public void setOver(int over) {
        this.over = over;
    }
    public int getBalls() {
        return balls;
    }
    public void setBalls(int balls) {
        this.balls = balls;
    }
    
}
