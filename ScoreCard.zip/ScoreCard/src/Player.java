public class Player {
    String playerName;
    int runs;
    int noOf4s;
    int noOf6s;
    int balls;
    
    public Player(String playerName) {
        this.playerName = playerName;
    }
    public String getPlayerName() {
        return playerName;
    }
    public int getRuns() {
        return runs;
    }
    public void setRuns(int runs) {
        this.runs = runs;
    }
    public int getNoOf4s() {
        return noOf4s;
    }
    public void setNoOf4s(int noOf4s) {
        this.noOf4s = noOf4s;
    }
    public int getNoOf6s() {
        return noOf6s;
    }
    public void setNoOf6s(int noOf6s) {
        this.noOf6s = noOf6s;
    }
    public int getBalls() {
        return balls;
    }
    public void setBalls(int balls) {
        this.balls = balls;
    }
    
}
