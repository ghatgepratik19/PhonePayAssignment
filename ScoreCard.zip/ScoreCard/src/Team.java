import java.util.LinkedList;
import java.util.Queue;

public class Team {
    LinkedList<Player> players;
    Queue<Player> playerOrder;
    Score score;
    public Team(int numberOfPlayers,LinkedList<String> playerNames) {
        players = new LinkedList<>();
        for(int i=0;i<playerNames.size();i++){
            players.add(new Player(playerNames.get(i)));
        }
        playerOrder= new LinkedList<>();
        setPlayerOrder(players);
        score = new Score();
    }

    public void setPlayerOrder(LinkedList<Player> list){
        players=list;
        playerOrder.clear();
        for(Player p:list){
            playerOrder.add(p);
        }
    }
    
}
