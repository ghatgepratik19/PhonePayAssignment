public class LiveScore {
    public static Player batsman1;
    public static Player batsman2;
    public static void switchBatsman(){
        Player temp=batsman1;
        batsman1=batsman2;
        batsman2=temp;
    }
    public static void addRuns(Team team,int runs,boolean isExtra){
        team.score.totalScore += runs;
        if(!isExtra){
            batsman1.runs += runs;
            batsman1.balls += 1;
            if(runs%2==1){
                switchBatsman();
            }
            else if(runs%4==0){
                batsman1.noOf4s +=1;
            }else if(runs%6==0){
                batsman1.noOf6s +=1;
            }
        }
    }
    public static void PrintScorecard(Team team){
        System.out.println("Player Name   Score   4s   6s   Balls");
        for(Player p: team.players){
            System.out.println(p.playerName+"            "+p.runs+"       "+p.noOf4s+"    "+p.noOf6s+"    "+p.balls);
        }
        System.out.println("Total: "+team.score.totalScore+"/"+(team.players.size()-(team.playerOrder.size()+2)));
        System.out.println("Over: "+team.score.over);
    }
}
