## Getting Started

Here is a guideline to help you get started.

## Folder Structure

The workspace contains folders, where:

- `src`: the folder to maintain sources
- `lib`: the folder to maintain dependencies
- `resources` : the folder to maintain resources
   resources contains data.json file which contains data required for application
Meanwhile, the compiled output files will be generated in the `bin` folder by default.

## Dependency Management

Added dependency in lib folder for json

## How to run
Run main method in App.java class.

## Input data
data from data.json in Resources folder
Runs for each ball from user console